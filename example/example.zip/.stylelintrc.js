module.exports = {
  extends: ['@alexlit/lint-kit/.stylelintrc.js'],

  ignoreFiles: [...require('@alexlit/lint-kit/.stylelintrc.js').ignoreFiles],
};