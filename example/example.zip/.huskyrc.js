module.exports = {
  ...require('@alexlit/lint-kit/.huskyrc.js'),
};
