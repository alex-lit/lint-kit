module.exports = {
  extends: ['@alexlit/lint-kit/.commitlintrc.js'],
};