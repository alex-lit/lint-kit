module.exports = {
  ...require('@alexlit/lint-kit/.lintstagedrc.js'),
};
