module.exports = {
  ...require('@alexlit/lint-kit/.prettierrc.js'),
};