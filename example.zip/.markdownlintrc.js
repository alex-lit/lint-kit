module.exports = {
  ...require('@alexlit/lint-kit/.markdownlintrc.js'),
};
