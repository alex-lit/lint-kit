module.exports = {
  extends: ['./node_modules/@alexlit/lint-kit/.eslintrc.js'],
};
